class Payment {
  final int mes;
  final double monto;

  Payment(this.mes, this.monto);
}
