import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../controllers/payment_controller.dart';
import '../models/payment_model.dart';

class HomeView extends StatefulWidget {
  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  final controller = PaymentController();
  final _formKey = GlobalKey<FormState>();

  List<Payment> pagos = [];
  final TextEditingController _mesesController = TextEditingController(text: "20");
  final TextEditingController _pagoController = TextEditingController(text: "10");

  void _calcular() {
    if (_formKey.currentState!.validate()) {
      final meses = int.parse(_mesesController.text);
      final pagoInicial = double.parse(_pagoController.text);

      pagos = controller.calcularPagos(meses, pagoInicial);
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final total = controller.calcularTotal(pagos);

    return Scaffold(
      appBar: AppBar(
        title: Text("Crédito Fácil"),
        backgroundColor: Colors.teal,
      ),
      backgroundColor: Color(0xFFF0F0F0),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: Card(
                elevation: 5,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Text("Ingrese los datos", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      SizedBox(height: 10),
                      Row(
                        children: [
                          // Campo meses
                          Expanded(
                            child: TextFormField(
                              controller: _mesesController,
                              keyboardType: TextInputType.number,
                              decoration: InputDecoration(labelText: "Meses"),
                              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                              validator: (value) {
                                if (value == null || value.isEmpty) return "Ingrese los meses";
                                int? val = int.tryParse(value);
                                if (val == null || val <= 0) return "Debe ser un número entero positivo";
                                return null;
                              },
                            ),
                          ),
                          SizedBox(width: 10),
                          // Campo pago inicial
                          Expanded(
                            child: TextFormField(
                              controller: _pagoController,
                              keyboardType: TextInputType.numberWithOptions(decimal: true),
                              decoration: InputDecoration(labelText: "Pago inicial (\$)"),
                              inputFormatters: [
                                FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}')),
                              ],
                              validator: (value) {
                                if (value == null || value.isEmpty) return "Ingrese el pago";
                                double? val = double.tryParse(value);
                                if (val == null || val <= 0) return "Debe ser número positivo";
                                return null;
                              },
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      ElevatedButton.icon(
                        onPressed: _calcular,
                        icon: Icon(Icons.calculate),
                        label: Text("Calcular"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.teal,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),

            // Lista de pagos
            Card(
              elevation: 3,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Container(
                padding: EdgeInsets.all(16),
                height: 300,
                child: ListView.builder(
                  physics: BouncingScrollPhysics(),
                  itemCount: pagos.length,
                  itemBuilder: (_, i) {
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.teal[300],
                        child: Text("${pagos[i].mes}"),
                      ),
                      title: Text("Pago: \$${pagos[i].monto.toStringAsFixed(2)}"),
                    );
                  },
                ),
              ),
            ),

            SizedBox(height: 10),

            // Total pagado
            Text(
              "Total Pagado: \$${total.toStringAsFixed(2)}",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.teal),
            ),
          ],
        ),
      ),
    );
  }
}
