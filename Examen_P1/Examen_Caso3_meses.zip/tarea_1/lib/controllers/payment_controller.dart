import '../models/payment_model.dart';

class PaymentController {
  List<Payment> calcularPagos(int meses, double pagoInicial) {
    List<Payment> pagos = [];
    double monto = pagoInicial;

    for (int i = 1; i <= meses; i++) {
      pagos.add(Payment(i, monto));
      monto *= 2;
    }

    return pagos;
  }

  double calcularTotal(List<Payment> pagos) {
    return pagos.fold(0, (suma, pago) => suma + pago.monto);
  }
}
