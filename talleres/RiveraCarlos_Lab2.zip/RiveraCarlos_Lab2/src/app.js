const express = require('express');
const userRoutes = require('./routes/user.routes');

const app = express();

// Middleware para parsear cuerpos JSON
app.use(express.json());

// Ruta base para usuarios
app.use('/api/users', userRoutes);

// Manejo de rutas no encontradas (404)
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

module.exports = app;