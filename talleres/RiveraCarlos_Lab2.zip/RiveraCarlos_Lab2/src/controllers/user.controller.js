// Base de datos simulada en memoria
let users = [];

// Obtener todos los usuarios
function getAllUsers(req, res) {
  res.json(users);
}

// Crear un nuevo usuario si se proveen name e email válidos
function createUser(req, res) {
  // Check if req.body is null or undefined
  if (!req.body) {
    return res.status(400).json({ message: 'Name and Email are required' });
  }

  const { name, email } = req.body;

  // Validación: name y email deben ser strings no vacíos
  if (typeof name !== 'string' || name.trim() === '' || typeof email !== 'string' || email.trim() === '') {
    return res.status(400).json({ message: 'Name and Email are required' });
  }

  const newUser = {
    id: Date.now(),
    name: name.trim(),
    email: email.trim()
  };

  users.push(newUser);
  res.status(201).json(newUser);
}

// Function to reset users array for testing
function resetUsers() {
  users = [];
}

module.exports = { getAllUsers, createUser, users, resetUsers };