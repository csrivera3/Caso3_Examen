const request = require('supertest');
const app = require('../src/app');

describe('User API', () => {
    // Clear the in-memory database before each test to ensure isolation
    beforeEach(async () => {
        const userController = require('../src/controllers/user.controller');
        userController.resetUsers(); // Use resetUsers function to clear users
    });

    // Existing tests
    test('GET /api/users debería devolver una lista vacía inicialmente', async () => {
        const res = await request(app).get('/api/users');
        expect(res.statusCode).toBe(200);
        expect(res.body).toEqual([]);
    });

    test('POST /api/users debería crear un nuevo usuario', async () => {
        const newUser = { name: 'Anthony Villarreal', email: 'anthony@example.com' };
        const res = await request(app)
        .post('/api/users')
        .send(newUser);
        expect(res.statusCode).toBe(201);
        expect(res.body).toHaveProperty('id');
        expect(res.body.name).toBe('Anthony Villarreal');
    });

    test('POST /api/users debería fallar si los datos están incompletos', async () => {
        const res = await request(app)
        .post('/api/users')
        .send({ name: 'Anthony' }); // Falta el email
        expect(res.statusCode).toBe(400);
        expect(res.body).toHaveProperty('message', 'Name and Email are required');
    });

    test('POST /api/users debería fallar si el nombre es un número', async () => {
        const res = await request(app)
        .post('/api/users')
        .send({ name: 123, email: 'anthony@example.com' });
        expect(res.statusCode).toBe(400);
        expect(res.body).toHaveProperty('message', 'Name and Email are required');
    });

    test('POST /api/users debería fallar si el email es un número', async () => {
        const res = await request(app)
        .post('/api/users')
        .send({ name: 'Anthony', email: 123 });
        expect(res.statusCode).toBe(400);
        expect(res.body).toHaveProperty('message', 'Name and Email are required');
    });

    test('POST /api/users debería fallar si el nombre es solo espacios', async () => {
        const res = await request(app)
        .post('/api/users')
        .send({ name: '   ', email: 'anthony@example.com' });
        expect(res.statusCode).toBe(400);
        expect(res.body).toHaveProperty('message', 'Name and Email are required');
    });

    test('POST /api/users debería fallar si el email es solo espacios', async () => {
        const res = await request(app)
        .post('/api/users')
        .send({ name: 'Anthony', email: '   ' });
        expect(res.statusCode).toBe(400);
        expect(res.body).toHaveProperty('message', 'Name and Email are required');
    });

    test('POST /api/users debería fallar si el nombre es null', async () => {
        const res = await request(app)
        .post('/api/users')
        .send({ name: null, email: 'anthony@example.com' });
        expect(res.statusCode).toBe(400);
        expect(res.body).toHaveProperty('message', 'Name and Email are required');
    });

    test('POST /api/users debería fallar si el email es null', async () => {
        const res = await request(app)
        .post('/api/users')
        .send({ name: 'Anthony', email: null });
        expect(res.statusCode).toBe(400);
        expect(res.body).toHaveProperty('message', 'Name and Email are required');
    });

    test('POST /api/users debería fallar si el cuerpo es null', async () => {
        const res = await request(app)
        .post('/api/users')
        .send(null);
        expect(res.statusCode).toBe(400);
        expect(res.body).toHaveProperty('message', 'Name and Email are required');
    });

    test('POST /api/users debería recortar espacios en nombre y email', async () => {
        const newUser = { name: '  Anthony  ', email: '  anthony@example.com  ' };
        const res = await request(app)
        .post('/api/users')
        .send(newUser);
        expect(res.statusCode).toBe(201);
        expect(res.body.name).toBe('Anthony');
        expect(res.body.email).toBe('anthony@example.com');
    });

    test('GET /api/users debería devolver usuarios en el orden correcto después de múltiples creaciones', async () => {
        await request(app)
        .post('/api/users')
        .send({ name: 'Anthony', email: 'anthony@example.com' });
        await request(app)
        .post('/api/users')
        .send({ name: 'María', email: 'maria@example.com' });

        const res = await request(app).get('/api/users');
        expect(res.statusCode).toBe(200);
        expect(res.body).toHaveLength(2);
        expect(res.body[0].name).toBe('Anthony');
        expect(res.body[1].name).toBe('María');
    });

    test('POST /api/users debería fallar si el nombre es un objeto', async () => {
        const res = await request(app)
        .post('/api/users')
        .send({ name: { value: 'Anthony' }, email: 'anthony@example.com' });
        expect(res.statusCode).toBe(400);
        expect(res.body).toHaveProperty('message', 'Name and Email are required');
    });

    test('POST /api/users debería fallar si el email es un objeto', async () => {
        const res = await request(app)
        .post('/api/users')
        .send({ name: 'Anthony', email: { value: 'anthony@example.com' } });
        expect(res.statusCode).toBe(400);
        expect(res.body).toHaveProperty('message', 'Name and Email are required');
    });

    test('POST /api/users debería manejar nombres con caracteres especiales', async () => {
        const newUser = { name: 'José Pérez-Ñúñez', email: 'jose@example.com' };
        const res = await request(app)
        .post('/api/users')
        .send(newUser);
        expect(res.statusCode).toBe(201);
        expect(res.body).toHaveProperty('id');
        expect(res.body.name).toBe('José Pérez-Ñúñez');
        expect(res.body.email).toBe('jose@example.com');
    });

    test('GET /api/users debería devolver una lista vacía después de resetear usuarios', async () => {
        // Add a user
        await request(app)
        .post('/api/users')
        .send({ name: 'Anthony', email: 'anthony@example.com' });
        // Reset users
        const userController = require('../src/controllers/user.controller');
        userController.resetUsers(); // Use resetUsers function
        // Check GET
        const res = await request(app).get('/api/users');
        expect(res.statusCode).toBe(200);
        expect(res.body).toHaveLength(0);
    });

    // Additional test cases
    test('POST /api/users debería fallar si el nombre es un arreglo', async () => {
        const res = await request(app)
        .post('/api/users')
        .send({ name: ['Anthony'], email: 'anthony@example.com' });
        expect(res.statusCode).toBe(400);
        expect(res.body).toHaveProperty('message', 'Name and Email are required');
    });

    test('POST /api/users debería fallar si el email es un arreglo', async () => {
        const res = await request(app)
        .post('/api/users')
        .send({ name: 'Anthony', email: ['anthony@example.com'] });
        expect(res.statusCode).toBe(400);
        expect(res.body).toHaveProperty('message', 'Name and Email are required');
    });

    test('POST /api/users debería manejar emails con subdominios', async () => {
        const newUser = { name: 'Anthony', email: 'anthony@sub.domain.com' };
        const res = await request(app)
        .post('/api/users')
        .send(newUser);
        expect(res.statusCode).toBe(201);
        expect(res.body).toHaveProperty('id');
        expect(res.body.name).toBe('Anthony');
        expect(res.body.email).toBe('anthony@sub.domain.com');
    });

    test('GET /api/users debería mantener el orden después de múltiples creaciones rápidas', async () => {
        const users = [
        { name: 'Anthony', email: 'anthony@example.com' },
        { name: 'María', email: 'maria@example.com' },
        { name: 'José', email: 'jose@example.com' }
        ];
        await Promise.all(users.map(user => 
        request(app).post('/api/users').send(user)
        ));

        const res = await request(app).get('/api/users');
        expect(res.statusCode).toBe(200);
        expect(res.body).toHaveLength(3);
        expect(res.body[0].name).toBe('Anthony');
        expect(res.body[1].name).toBe('María');
        expect(res.body[2].name).toBe('José');
    });
});